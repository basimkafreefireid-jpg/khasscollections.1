/* ============================================
   KHASS COLLECTIONS — site logic
   In-memory state only (no localStorage — not supported in this environment).
   ============================================ */

const PRODUCTS = [
  {
    id: 'p1', name: 'Noor Bandana Tee', img: 'assets/p1-bandana-noor.jpg',
    price: 1299, oldPrice: 1599, badge: 'AZADI SALE',
    desc: 'Oversized black tee with an intricate bandana-style border framing "Noor" (light) in Urdu script. Heavyweight cotton, boxy streetwear fit.'
  },
  {
    id: 'p2', name: 'Spider Vibes Only Tee', img: 'assets/p2-spider-vibes.jpg',
    price: 1299, oldPrice: 1599, badge: 'AZADI SALE',
    desc: 'Bold gothic "Spider — Vibes Only" graphic on a crisp white oversized tee. Statement back print, made for the streets.'
  },
  {
    id: 'p3', name: 'Left It All Behind Tee', img: 'assets/p3-behind.jpg',
    price: 1299, oldPrice: 1599, badge: 'AZADI SALE',
    desc: 'Moody anime-inspired back print — "To the one who left it all behind." Relaxed fit, soft heavyweight fabric.'
  },
  {
    id: 'p4', name: 'Money Money Tee', img: 'assets/p4-money.jpg',
    price: 1299, oldPrice: 1599, badge: 'AZADI SALE',
    desc: 'Mirrored "MONEY" typographic print running vertically down the back. Clean black tee, premium fit.'
  },
  {
    id: 'p5', name: 'Zindagi Bandana Tee', img: 'assets/p5-bandana-zindagi.jpg',
    price: 1299, oldPrice: 1599, badge: 'AZADI SALE',
    desc: 'Sister piece to the Noor tee — bandana border framing "Zindagi" (life) in Urdu script on black cotton.'
  },
  {
    id: 'p6', name: '23 Chicago Tee', img: 'assets/p6-23-chicago.jpg',
    price: 1299, oldPrice: 1599, badge: 'NEW DROP',
    desc: 'Sky blue jersey-style tee with a bold "23 Chicago" numeral graphic and mixed racing badges. Oversized athletic fit.'
  },
  {
    id: 'p7', name: 'Built From Pain Tee', img: 'assets/p7-panther-pain.jpg',
    price: 1299, oldPrice: 1599, badge: 'AZADI SALE',
    desc: 'Fierce black panther illustration with "Built From Pain" wordmark on white cotton. Statement streetwear graphic.'
  },
  {
    id: 'p8', name: 'Sabr Rug Tee', img: 'assets/p8-sabr-rug.jpg',
    price: 1299, oldPrice: 1599, badge: 'AZADI SALE',
    desc: 'Rich rug-pattern collage in deep red with "Sabr" (patience) in Urdu script. Black oversized tee.'
  },
  // Reserved slots — original branded mockups used licensed logos (BMW, Porsche,
  // Ferrari, One Piece) and can't be sold as-is. Swap in your own artwork here.
  { id: 'r1', name: 'Coming Soon', reserved: true, note: 'Slot reserved — add your own design' },
  { id: 'r2', name: 'Coming Soon', reserved: true, note: 'Slot reserved — add your own design' },
  { id: 'r3', name: 'Coming Soon', reserved: true, note: 'Slot reserved — add your own design' },
  { id: 'r4', name: 'Coming Soon', reserved: true, note: 'Slot reserved — add your own design' },
  { id: 'r5', name: 'Coming Soon', reserved: true, note: 'Slot reserved — add your own design' },
];

const SIZES = ['S', 'M', 'L', 'XL', 'XXL'];
const DELIVERY_FEE = 200;

let cart = []; // {id, name, img, price, size, qty}
let activeProduct = null;
let activeSize = null;
let activeQty = 1;

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
const fmt = (n) => 'Rs. ' + n.toLocaleString('en-PK');

/* ---------------- render product grid ---------------- */
function renderGrid() {
  const grid = $('#productGrid');
  grid.innerHTML = PRODUCTS.map(p => {
    if (p.reserved) {
      return `
        <div class="card disabled reveal">
          <div class="card-media">
            <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--text-dim);font-size:12px;text-align:center;padding:14px;">
              ${p.note}
            </div>
            <span class="badge badge-soon">Coming soon</span>
          </div>
          <div class="card-body">
            <div class="card-name">${p.name}</div>
          </div>
        </div>`;
    }
    return `
      <div class="card reveal" data-id="${p.id}">
        <div class="card-media" data-open="${p.id}">
          <span class="badge">${p.badge}</span>
          <img src="${p.img}" alt="${p.name}" loading="lazy">
          <div class="card-actions">
            <button class="mini-btn add" data-quickadd="${p.id}">Quick Add</button>
            <button class="mini-btn view" data-open="${p.id}">View</button>
          </div>
        </div>
        <div class="card-body">
          <div class="card-name">${p.name}</div>
          <div class="card-prices">
            <span class="card-old">${fmt(p.oldPrice)}</span>
            <span class="card-new">${fmt(p.price)}</span>
          </div>
        </div>
      </div>`;
  }).join('');

  $$('[data-open]', grid).forEach(el => el.addEventListener('click', () => openProductModal(el.dataset.open)));
  $$('[data-quickadd]', grid).forEach(el => el.addEventListener('click', (e) => {
    e.stopPropagation();
    const p = PRODUCTS.find(x => x.id === el.dataset.quickadd);
    addToCart(p, 'M', 1);
    showToast(`${p.name} added to cart`);
  }));

  observeReveals();
}

/* ---------------- product modal ---------------- */
function openProductModal(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p || p.reserved) return;
  activeProduct = p;
  activeSize = null;
  activeQty = 1;

  $('#pmImage').src = p.img;
  $('#pmImage').alt = p.name;
  $('#pmName').textContent = p.name;
  $('#pmOld').textContent = fmt(p.oldPrice);
  $('#pmNew').textContent = fmt(p.price);
  $('#pmDesc').textContent = p.desc;
  $('#pmQty').textContent = activeQty;

  $('#pmSizes').innerHTML = SIZES.map(s => `<button class="size-chip" data-size="${s}">${s}</button>`).join('');
  $$('.size-chip', $('#pmSizes')).forEach(chip => {
    chip.addEventListener('click', () => {
      $$('.size-chip', $('#pmSizes')).forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeSize = chip.dataset.size;
    });
  });

  $('#productModal').classList.add('show');
  document.body.style.overflow = 'hidden';
}

function closeProductModal() {
  $('#productModal').classList.remove('show');
  document.body.style.overflow = '';
}

/* ---------------- cart ---------------- */
function addToCart(product, size, qty) {
  const existing = cart.find(i => i.id === product.id && i.size === size);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id: product.id, name: product.name, img: product.img, price: product.price, size, qty });
  }
  renderCart();
  pulseCartIcon();
}

function changeQty(index, delta) {
  cart[index].qty += delta;
  if (cart[index].qty <= 0) cart.splice(index, 1);
  renderCart();
}

function removeItem(index) {
  cart.splice(index, 1);
  renderCart();
}

function cartSubtotal() {
  return cart.reduce((sum, i) => sum + i.price * i.qty, 0);
}

function renderCart() {
  const body = $('#drawerBody');
  const countEl = $('#cartCount');
  const totalItems = cart.reduce((s, i) => s + i.qty, 0);
  countEl.textContent = totalItems;
  countEl.style.display = totalItems > 0 ? 'flex' : 'none';

  if (cart.length === 0) {
    body.innerHTML = `<div class="empty-cart">Your cart is empty.<br><br>Time to find something Khass. ✨</div>`;
  } else {
    body.innerHTML = cart.map((item, idx) => `
      <div class="cart-item">
        <img src="${item.img}" alt="${item.name}">
        <div class="cart-item-info">
          <div class="name">${item.name}</div>
          <div class="meta">Size: ${item.size}</div>
          <div class="qty-row">
            <button class="qty-btn" data-dec="${idx}">−</button>
            <span class="qty-val">${item.qty}</span>
            <button class="qty-btn" data-inc="${idx}">+</button>
            <button class="remove-btn" data-remove="${idx}">Remove</button>
          </div>
        </div>
        <div class="item-price">${fmt(item.price * item.qty)}</div>
      </div>
    `).join('');

    $$('[data-inc]', body).forEach(b => b.addEventListener('click', () => changeQty(+b.dataset.inc, 1)));
    $$('[data-dec]', body).forEach(b => b.addEventListener('click', () => changeQty(+b.dataset.dec, -1)));
    $$('[data-remove]', body).forEach(b => b.addEventListener('click', () => removeItem(+b.dataset.remove)));
  }

  const subtotal = cartSubtotal();
  const delivery = cart.length ? DELIVERY_FEE : 0;
  $('#sumSubtotal').textContent = fmt(subtotal);
  $('#sumDelivery').textContent = cart.length ? fmt(delivery) : '—';
  $('#sumTotal').textContent = fmt(subtotal + delivery);
  $('#checkoutBtn').disabled = cart.length === 0;
  $('#checkoutBtn').style.opacity = cart.length === 0 ? '.5' : '1';
  $('#checkoutBtn').style.pointerEvents = cart.length === 0 ? 'none' : 'auto';
}

function openCart() {
  $('#cartOverlay').classList.add('show');
  $('#cartDrawer').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeCart() {
  $('#cartOverlay').classList.remove('show');
  $('#cartDrawer').classList.remove('open');
  document.body.style.overflow = '';
}
function pulseCartIcon() {
  const btn = $('#cartToggle');
  btn.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.2)' }, { transform: 'scale(1)' }], { duration: 350, easing: 'ease-out' });
}

/* ---------------- toast ---------------- */
let toastTimer;
function showToast(msg) {
  const t = $('#toast');
  t.querySelector('span').textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}

/* ---------------- checkout ---------------- */
function openCheckout() {
  if (cart.length === 0) return;
  closeCart();
  const subtotal = cartSubtotal();
  $('#coSubtotal').textContent = fmt(subtotal);
  $('#coDelivery').textContent = fmt(DELIVERY_FEE);
  $('#coTotal').textContent = fmt(subtotal + DELIVERY_FEE);
  $('#checkoutModal').classList.add('show');
  document.body.style.overflow = 'hidden';
}
function closeCheckout() {
  $('#checkoutModal').classList.remove('show');
  document.body.style.overflow = '';
}

function validateCheckout() {
  let valid = true;
  const fields = [
    { id: 'fName', check: v => v.trim().length >= 3 },
    { id: 'fPhone', check: v => /^(\+92|0)[0-9]{10}$/.test(v.replace(/[\s-]/g, '')) },
    { id: 'fAddress', check: v => v.trim().length >= 8 },
    { id: 'fCity', check: v => v.trim().length >= 2 },
    { id: 'fProvince', check: v => v.trim().length > 0 },
  ];
  fields.forEach(f => {
    const el = $('#' + f.id);
    const wrap = el.closest('.field');
    if (!f.check(el.value)) {
      wrap.classList.add('error');
      valid = false;
    } else {
      wrap.classList.remove('error');
    }
  });
  return valid;
}

function placeOrder(e) {
  e.preventDefault();
  if (!validateCheckout()) {
    showToast('Please fix the highlighted fields');
    return;
  }
  const orderId = 'KC' + Math.floor(100000 + Math.random() * 900000);
  $('#orderId').textContent = 'Order #' + orderId;
  closeCheckout();
  cart = [];
  renderCart();
  $('#checkoutForm').reset();
  openSuccess();
}

function openSuccess() {
  $('#successModal').classList.add('show');
  document.body.style.overflow = 'hidden';
  launchConfetti();
}
function closeSuccess() {
  $('#successModal').classList.remove('show');
  document.body.style.overflow = '';
}

function launchConfetti() {
  const wrap = $('#confettiWrap');
  wrap.innerHTML = '';
  const colors = ['#a855f7', '#38bdf8', '#f0289a', '#39ff88', '#ff7a1a'];
  for (let i = 0; i < 40; i++) {
    const s = document.createElement('span');
    s.style.left = Math.random() * 100 + '%';
    s.style.background = colors[Math.floor(Math.random() * colors.length)];
    s.style.animationDuration = (2 + Math.random() * 1.5) + 's';
    s.style.animationDelay = (Math.random() * 0.4) + 's';
    s.style.borderRadius = Math.random() > .5 ? '50%' : '2px';
    wrap.appendChild(s);
  }
}

/* ---------------- search ---------------- */
function openSearch() {
  $('#searchOverlay').classList.add('show');
  document.body.style.overflow = 'hidden';
  $('#searchInput').value = '';
  renderSearch('');
  setTimeout(() => $('#searchInput').focus(), 200);
}
function closeSearch() {
  $('#searchOverlay').classList.remove('show');
  document.body.style.overflow = '';
}
function renderSearch(q) {
  const results = $('#searchResults');
  const query = q.trim().toLowerCase();
  const list = PRODUCTS.filter(p => !p.reserved && (query === '' || p.name.toLowerCase().includes(query)));
  if (list.length === 0) {
    results.innerHTML = `<div style="color:var(--text-dim);text-align:center;padding:30px;">No products found for "${q}"</div>`;
    return;
  }
  results.innerHTML = list.map(p => `
    <div class="search-item" data-open="${p.id}">
      <img src="${p.img}" alt="${p.name}">
      <div>
        <div class="sn">${p.name}</div>
        <div class="sp">${fmt(p.price)}</div>
      </div>
    </div>
  `).join('');
  $$('[data-open]', results).forEach(el => el.addEventListener('click', () => {
    closeSearch();
    openProductModal(el.dataset.open);
  }));
}

/* ---------------- custom order upload ---------------- */
function initUpload() {
  const zone = $('#uploadZone');
  const input = $('#customFile');
  const preview = $('#customPreview');

  ['dragover', 'dragenter'].forEach(evt => zone.addEventListener(evt, (e) => { e.preventDefault(); zone.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach(evt => zone.addEventListener(evt, (e) => { e.preventDefault(); zone.classList.remove('drag'); }));
  zone.addEventListener('drop', (e) => {
    if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files);
  });
  input.addEventListener('change', () => handleFiles(input.files));

  function handleFiles(files) {
    [...files].forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = document.createElement('img');
        img.src = e.target.result;
        preview.appendChild(img);
      };
      reader.readAsDataURL(file);
    });
    showToast('Design received — we\'ll reach out to confirm details');
  }
}

/* ---------------- scroll reveal ---------------- */
function observeReveals() {
  const els = $$('.reveal:not(.in)');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  els.forEach(el => io.observe(el));
}

/* ---------------- mobile menu ---------------- */
function initMobileMenu() {
  const btn = $('#hamburger');
  const menu = $('#mobileMenu');
  btn.addEventListener('click', () => {
    btn.classList.toggle('open');
    menu.classList.toggle('open');
    document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
  });
  $$('#mobileMenu a').forEach(a => a.addEventListener('click', () => {
    btn.classList.remove('open');
    menu.classList.remove('open');
    document.body.style.overflow = '';
  }));
}

/* ---------------- init ---------------- */
document.addEventListener('DOMContentLoaded', () => {
  renderGrid();
  renderCart();
  observeReveals();
  initMobileMenu();
  initUpload();

  // loader
  setTimeout(() => $('#loader').classList.add('hide'), 700);

  // cart
  $('#cartToggle').addEventListener('click', openCart);
  $('#cartOverlay').addEventListener('click', closeCart);
  $('#cartClose').addEventListener('click', closeCart);
  $('#checkoutBtn').addEventListener('click', openCheckout);

  // product modal
  $('#pmClose').addEventListener('click', closeProductModal);
  $('#productModal').addEventListener('click', (e) => { if (e.target.id === 'productModal') closeProductModal(); });
  $('#pmQtyMinus').addEventListener('click', () => { if (activeQty > 1) { activeQty--; $('#pmQty').textContent = activeQty; } });
  $('#pmQtyPlus').addEventListener('click', () => { activeQty++; $('#pmQty').textContent = activeQty; });
  $('#pmAddCart').addEventListener('click', () => {
    if (!activeSize) { showToast('Please select a size'); return; }
    addToCart(activeProduct, activeSize, activeQty);
    showToast(`${activeProduct.name} added to cart`);
    closeProductModal();
  });
  $('#pmBuyNow').addEventListener('click', () => {
    if (!activeSize) { showToast('Please select a size'); return; }
    addToCart(activeProduct, activeSize, activeQty);
    closeProductModal();
    openCheckout();
  });

  // checkout
  $('#checkoutClose').addEventListener('click', closeCheckout);
  $('#checkoutModal').addEventListener('click', (e) => { if (e.target.id === 'checkoutModal') closeCheckout(); });
  $('#checkoutForm').addEventListener('submit', placeOrder);

  // success
  $('#successClose').addEventListener('click', closeSuccess);
  $('#successContinue').addEventListener('click', closeSuccess);

  // search
  $('#searchToggle').addEventListener('click', openSearch);
  $('#searchToggleMobile').addEventListener('click', openSearch);
  $('#searchClose').addEventListener('click', closeSearch);
  $('#searchInput').addEventListener('input', (e) => renderSearch(e.target.value));

  // hero / shop now buttons
  $$('[data-scroll-shop]').forEach(b => b.addEventListener('click', () => {
    $('#shop').scrollIntoView({ behavior: 'smooth' });
  }));

  // escape key closes topmost overlay
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if ($('#searchOverlay').classList.contains('show')) closeSearch();
    else if ($('#successModal').classList.contains('show')) closeSuccess();
    else if ($('#checkoutModal').classList.contains('show')) closeCheckout();
    else if ($('#productModal').classList.contains('show')) closeProductModal();
    else if ($('#cartDrawer').classList.contains('open')) closeCart();
  });
});
